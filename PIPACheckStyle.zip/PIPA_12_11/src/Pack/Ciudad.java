package Pack;

/**
 * La clase Ciudad representa una entidad que almacena las rutas de los archivos XML
 * de nodos y bordes asociados a una ciudad en el contexto de la aplicación de lectura de mapas.
 */
public class Ciudad{
  private String xmlNodes;
  private String xmlEdges;

  public Ciudad(String xmlNodes, String xmlEdges){
    this.xmlNodes = xmlNodes;
    this.xmlEdges = xmlEdges;
   }

  public String getXmlNodes(){
    return xmlNodes;
  }

  public String getXmlEdges(){
    return xmlEdges;
  }
}