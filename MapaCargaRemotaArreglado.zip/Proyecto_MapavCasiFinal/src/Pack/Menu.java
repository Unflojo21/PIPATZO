package Pack;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.*;
import javax.swing.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class Menu extends JFrame {
	private static final long serialVersionUID = 1L;
	static Map<String, Nodo> nodosMap = new HashMap<>();
	private LinkedList<Nodo> Nodos = new LinkedList<>();
	private LinkedList<Edge> Edges = new LinkedList<>();
	private LinkedList<Nodo> NodosOriginales = new LinkedList<>();
	private LinkedList<Edge> EdgesOriginales = new LinkedList<>();
	private double xv = 0, xv2 = 0, yv = 0, yv2 = 0;

	private JPanel contentPane;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Menu frame = new Menu();
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Menu() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 652, 393);

		JTabbedPane tabbedPane = new JTabbedPane();

		/*---------------PESTAÑA DE CARGA LOCAL-------------------*/
		JPanel panelCargaLocal = new JPanel();
		panelCargaLocal.setLayout(null);

		JButton LeerNodo = new JButton("Leer Nodos");
		LeerNodo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				File f = new File("C:\\Users\\maxm2\\OneDrive\\Escritorio\\Proyecto_Mapav2");
				JFileChooser fileChooser = new JFileChooser();
				fileChooser.setCurrentDirectory(f);
				int returnValue = fileChooser.showOpenDialog(null);

				if (returnValue == JFileChooser.APPROVE_OPTION) {
					File selectedFile = fileChooser.getSelectedFile();
					leerNodoXML(selectedFile);
				}
			}
			/*leerNodoXML : lee los nodos contenidos en el archivo nodes.xml cargado de manera local, retorna los nodos leidos del archivo*/
			private LinkedList<Nodo> leerNodoXML(File selectedFile) {
				try {
					DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
					DocumentBuilder builder = factory.newDocumentBuilder();
					Document doc = builder.parse(selectedFile);

					NodeList nodeList = doc.getElementsByTagName("row");
					for (int i = 0; i < nodeList.getLength(); i++) {
						Element elemento = (Element) nodeList.item(i);
						double x = Double.parseDouble(elemento.getElementsByTagName("x").item(0).getTextContent());
						double y = Double.parseDouble(elemento.getElementsByTagName("y").item(0).getTextContent());
						String osmid = elemento.getElementsByTagName("osmid").item(0).getTextContent();
						Nodo nodo = new Nodo(x, y, osmid);
						Nodos.add(nodo);
						if (xv2 == 0) {
							xv2 = x;
						} else {
							if (xv2 < x) {
								xv2 = x;
							}
						}
						if (xv > x) {
							xv = x;
						}
						if (yv2 == 0) {
							yv2 = y;
						} else {
							if (yv2 < y) {
								yv2 = y;
							}
						}
						if (yv > y) {
							yv = y;
						}

					}

					for (Nodo nodo : Nodos) {
						nodo.setXv(xv);
						nodo.setXv2(xv2);
						nodo.setYv(yv);
						nodo.setYv2(yv2);
					}
					System.out.println("X: " + xv + " X2: " + xv2);
					System.out.println("Y: " + yv + " Y2: " + yv2);
					//NodosOriginales para el momento que se quiere reiniciar el mapa.
					NodosOriginales.addAll(Nodos);
				} catch (Exception e) {
					e.printStackTrace();
				}

				return Nodos;
			}
		});
		LeerNodo.setFont(new Font("Arial Black", Font.PLAIN, 14));
		LeerNodo.setBounds(234, 200, 144, 21);
		panelCargaLocal.add(LeerNodo);

		JButton LeerEdges = new JButton("Leer Edges");
		LeerEdges.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				File f = new File("C:\\Users\\maxm2\\OneDrive\\Escritorio\\Proyecto_Mapav2");
				JFileChooser fileChooser = new JFileChooser();
				fileChooser.setCurrentDirectory(f);
				int returnValue = fileChooser.showOpenDialog(null);

				if (returnValue == JFileChooser.APPROVE_OPTION) {
					File selectedFile = fileChooser.getSelectedFile();
					leerEdgeXML(selectedFile);
				}
			}
			/*leerEdgeXML : lee los nodos contenidos en el archivo edges.xml cargado de manera local, retorna los edges leidos del archivo*/
			private LinkedList<Edge> leerEdgeXML(File selectedFile) {
				try {
					DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
					DocumentBuilder builder = factory.newDocumentBuilder();
					Document doc = builder.parse(selectedFile);

					NodeList nodeList = doc.getElementsByTagName("edge");
					for (int i = 0; i < nodeList.getLength(); i++) {
						Element elemento = (Element) nodeList.item(i);
						String u = elemento.getElementsByTagName("u").item(0).getTextContent();
						String v = elemento.getElementsByTagName("v").item(0).getTextContent();
						int k = Integer.parseInt(elemento.getElementsByTagName("k").item(0).getTextContent());
						String osmid = elemento.getElementsByTagName("osmid").item(0).getTextContent();
						String name = elemento.getElementsByTagName("name").item(0).getTextContent();

						// Busca y asocia los nodos usando el mapa
						Nodo nodoFuente = nodosMap.get(u);
						Nodo nodoDestino = nodosMap.get(v);

						// Verifica si los nodos existen antes de asociarlos
						if (nodoFuente != null && nodoDestino != null) {
						    Edge edge = new Edge(u, v, k, osmid, name, nodoFuente, nodoDestino);
						    Edges.add(edge);
						} else {
						    // Maneja el caso donde uno o ambos nodos no fueron encontrados
						    System.out.println("Nodo fuente o destino no encontrado para el borde.");
						}
					}
					//EdgesOriginales utilizado para el reinicio de mapa
					EdgesOriginales.addAll(Edges);
				} catch (Exception e) {
					e.printStackTrace();
				}

				return Edges;
			}
		});
		LeerEdges.setFont(new Font("Arial Black", Font.PLAIN, 14));
		LeerEdges.setBounds(234, 241, 144, 21);
		panelCargaLocal.add(LeerEdges);

		JButton mostrarMapa = new JButton("Mostrar Mapa");
		mostrarMapa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Map<String, Nodo> nodosMap = crearDiccionarioNodos(Nodos);
				for (Edge Edge : Edges) {
					Nodo nodoFuente = nodosMap.get(Edge.getU());
					Nodo nodoDestino = nodosMap.get(Edge.getV());
					Edge.setNodoFuente(nodoFuente);
					Edge.setNodoDestino(nodoDestino);
				}

				Ventana panel = new Ventana(Nodos, Edges, xv, yv, xv2, yv2);

				// Crear el JFrame y configurarlo
				JFrame frame = new JFrame("Dibujar Nodos y Bordes desde XML");
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setSize(800, 600);

				// Hacer visible el JFrame
				frame.setVisible(true);
			}
		});
		mostrarMapa.setFont(new Font("Arial Black", Font.PLAIN, 14));
		mostrarMapa.setBounds(234, 282, 144, 21);
		panelCargaLocal.add(mostrarMapa);

		/*---------------PESTAÑA DE CARGA REMOTA-------------------*/
		JPanel panelCargaRemota = new JPanel();
		panelCargaRemota.setLayout(null);

		JButton cargarArchivosRemotos = new JButton("Cargar Archivos Remotos");
		cargarArchivosRemotos.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        try {
		            // Crear una instancia de CiudadesProvider
		            CiudadesProvider ciudadesProvider = CiudadesProvider.instance();

		            // Mostrar la lista de ciudades disponibles
		            List<String> ciudades = ciudadesProvider.list();
		            StringBuilder message = new StringBuilder("Lista de ciudades disponibles:\n");

		            for (int i = 0; i < ciudades.size(); i++) {
		                message.append((i + 1)).append(". ").append(ciudades.get(i)).append("\n");
		            }

		            // Seleccion de Mapa
		            String selectedMapIndexStr = JOptionPane.showInputDialog(null, message.toString(), "Seleccione un mapa",
		                    JOptionPane.PLAIN_MESSAGE);

		            if (selectedMapIndexStr == null) {
		                return;
		            }

		            int selectedMapIndex = Integer.parseInt(selectedMapIndexStr);
		            if (selectedMapIndex < 1 || selectedMapIndex > ciudades.size()) {
		                JOptionPane.showMessageDialog(null, "Número de mapa no válido. Saliendo...", "Error",
		                        JOptionPane.ERROR_MESSAGE);
		                return;
		            }

		            String selectedMap = ciudades.get(selectedMapIndex - 1);

		            //Seleccion de mapa
		            System.out.println("Mapa seleccionado: " + selectedMap);
		            Ciudad c = ciudadesProvider.ciudad(selectedMap);

		            //Obtener los mapas seleccionados
		            String archivoNodos = c.getXmlNodes();
		            String archivoEdges = c.getXmlEdges();

		            System.out.println(c.getXmlEdges().length());
		            System.out.println(c.getXmlNodes().length());

		            //Carga de archivos de forma remota
		            ciudadesProvider.cargarArchivosRemotos(archivoNodos, archivoEdges);

		            System.out.println("Carga de archivos remotos completada");
		        } catch (IOException ex) {
		            ex.printStackTrace();
		        }
		    }
		});

		cargarArchivosRemotos.setFont(new Font("Arial Black", Font.PLAIN, 14));
		cargarArchivosRemotos.setBounds(234, 200, 250, 30);
		panelCargaRemota.add(cargarArchivosRemotos);
		
		/*---------------PESTAÑAS PARA EL PROGAMA-------------------*/
		tabbedPane.addTab("Acciones Locales", null, panelCargaLocal, "Realizar acciones locales");
		tabbedPane.addTab("Acciones Remotas", null, panelCargaRemota, "Realizar acciones con archivos remotos");

		JFrame frame = new JFrame("Ejemplo de Pestañas con Botones");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(800, 600);

		frame.getContentPane().add(tabbedPane);

		frame.setVisible(true);
	}

	private static Map<String, Nodo> crearDiccionarioNodos(List<Nodo> nodos) {
		Map<String, Nodo> nodosMap = new HashMap<>();
		for (Nodo nodo : nodos) {
			nodosMap.put(nodo.getOsmid(), nodo);
		}
		return nodosMap;
	}
}
