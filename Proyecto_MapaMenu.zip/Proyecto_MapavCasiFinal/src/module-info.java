/**
 * 
 */
/**
 * 
 */
module Proyecto_Mapa {
	requires java.desktop;
}