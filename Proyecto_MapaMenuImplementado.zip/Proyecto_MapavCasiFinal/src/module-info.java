/**
 * 
 */
/**
 * 
 */
module Proyecto_Mapa {
	requires java.desktop;
	requires java.xml;
	requires java.sql.rowset;
	requires org.json;
}