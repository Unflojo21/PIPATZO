package Pack;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.*;
import javax.swing.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class Menu extends JFrame {
	private static final long serialVersionUID = 1L;
	static Map<String, Nodo> nodosMap = new HashMap<>();
	private LinkedList<Nodo> Nodos = new LinkedList<>();
	private LinkedList<Edge> Edges = new LinkedList<>();
	private LinkedList<Nodo> NodosOriginales = new LinkedList<>();
	private LinkedList<Edge> EdgesOriginales = new LinkedList<>();
	private double xv = 0, xv2 = 0, yv = 0, yv2 = 0;

	private JPanel contentPane;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Menu frame = new Menu();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Menu() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 652, 393);

		JTabbedPane tabbedPane = new JTabbedPane();

		// Pestaña 1
		JPanel panel1 = new JPanel();
		panel1.setLayout(null);

		JButton LeerNodo = new JButton("Leer Nodos");
		LeerNodo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				File f = new File("C:\\Users\\maxm2\\OneDrive\\Escritorio\\Proyecto_Mapav2");
				JFileChooser fileChooser = new JFileChooser();
				fileChooser.setCurrentDirectory(f);
				int returnValue = fileChooser.showOpenDialog(null);

				if (returnValue == JFileChooser.APPROVE_OPTION) {
					File selectedFile = fileChooser.getSelectedFile();
					leerNodoXML(selectedFile);
				}
			}

			private LinkedList<Nodo> leerNodoXML(File selectedFile) {
				try {
					DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
					DocumentBuilder builder = factory.newDocumentBuilder();
					Document doc = builder.parse(selectedFile);

					NodeList nodeList = doc.getElementsByTagName("row");
					for (int i = 0; i < nodeList.getLength(); i++) {
						Element elemento = (Element) nodeList.item(i);
						double x = Double.parseDouble(elemento.getElementsByTagName("x").item(0).getTextContent());
						double y = Double.parseDouble(elemento.getElementsByTagName("y").item(0).getTextContent());
						String osmid = elemento.getElementsByTagName("osmid").item(0).getTextContent();
						Nodo nodo = new Nodo(x, y, osmid);
						Nodos.add(nodo);
						if (xv2 == 0) {
							xv2 = x;
						} else {
							if (xv2 < x) {
								xv2 = x;
							}
						}
						if (xv > x) {
							xv = x;
						}
						if (yv2 == 0) {
							yv2 = y;
						} else {
							if (yv2 < y) {
								yv2 = y;
							}
						}
						if (yv > y) {
							yv = y;
						}

					}

					for (Nodo nodo : Nodos) {
						nodo.setXv(xv);
						nodo.setXv2(xv2);
						nodo.setYv(yv);
						nodo.setYv2(yv2);
					}
					System.out.println("X: " + xv + " X2: " + xv2);
					System.out.println("Y: " + yv + " Y2: " + yv2);
					NodosOriginales.addAll(Nodos);
				} catch (Exception e) {
					e.printStackTrace();
				}

				return Nodos;
			}
		});
		LeerNodo.setFont(new Font("Arial Black", Font.PLAIN, 14));
		LeerNodo.setBounds(234, 200, 144, 21);
		panel1.add(LeerNodo);

		JButton LeerEdges = new JButton("Leer Edges");
		LeerEdges.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				File f = new File("C:\\Users\\maxm2\\OneDrive\\Escritorio\\Proyecto_Mapav2");
				JFileChooser fileChooser = new JFileChooser();
				fileChooser.setCurrentDirectory(f);
				int returnValue = fileChooser.showOpenDialog(null);

				if (returnValue == JFileChooser.APPROVE_OPTION) {
					File selectedFile = fileChooser.getSelectedFile();
					leerEdgeXML(selectedFile);
				}
			}

			private LinkedList<Edge> leerEdgeXML(File selectedFile) {
				try {
					DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
					DocumentBuilder builder = factory.newDocumentBuilder();
					Document doc = builder.parse(selectedFile);

					NodeList nodeList = doc.getElementsByTagName("edge");
					for (int i = 0; i < nodeList.getLength(); i++) {
						Element elemento = (Element) nodeList.item(i);
						String u = elemento.getElementsByTagName("u").item(0).getTextContent();
						String v = elemento.getElementsByTagName("v").item(0).getTextContent();
						int k = Integer.parseInt(elemento.getElementsByTagName("k").item(0).getTextContent());
						String osmid = elemento.getElementsByTagName("osmid").item(0).getTextContent();
						String name = elemento.getElementsByTagName("name").item(0).getTextContent();

						// Busca y asocia los nodos usando el mapa
						Nodo nodoFuente = nodosMap.get(u);
						Nodo nodoDestino = nodosMap.get(v);
						Edge edge = new Edge(u, v, k, osmid, name, nodoFuente, nodoDestino);
						Edges.add(edge);
					}
					EdgesOriginales.addAll(Edges);
				} catch (Exception e) {
					e.printStackTrace();
				}

				return Edges;
			}
		});
		LeerEdges.setFont(new Font("Arial Black", Font.PLAIN, 14));
		LeerEdges.setBounds(234, 241, 144, 21);
		panel1.add(LeerEdges);

		JButton Mostrar_Mapa = new JButton("Mostrar Mapa");
		Mostrar_Mapa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Map<String, Nodo> nodosMap = crearDiccionarioNodos(Nodos);
				for (Edge Edge : Edges) {
					Nodo nodoFuente = nodosMap.get(Edge.getU());
					Nodo nodoDestino = nodosMap.get(Edge.getV());
					Edge.setNodoFuente(nodoFuente);
					Edge.setNodoDestino(nodoDestino);
				}

				Ventana panel = new Ventana(Nodos, Edges, xv, yv, xv2, yv2);

				// Crear un JScrollPane que contenga el panel App
				JScrollPane scrollPane = new JScrollPane(panel);

				// Configurar el comportamiento de las barras de desplazamiento
				scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
				scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

				// Crear el JFrame y configurarlo
				JFrame frame = new JFrame("Dibujar Nodos y Bordes desde XML");
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setSize(800, 600);

				// Agregar el JScrollPane al contenido del JFrame
				frame.getContentPane().add(scrollPane);

				// Hacer visible el JFrame
				frame.setVisible(true);
			}
		});
		Mostrar_Mapa.setFont(new Font("Arial Black", Font.PLAIN, 14));
		Mostrar_Mapa.setBounds(234, 282, 144, 21);
		panel1.add(Mostrar_Mapa);

		// Pestaña 2
		JPanel panel2 = new JPanel();
		panel2.setLayout(null);

		JButton cargarArchivosRemotos = new JButton("Cargar Archivos Remotos");
		cargarArchivosRemotos.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        // Pedir al usuario que elija un mapa por consola
		        Scanner scanner = new Scanner(System.in);
		        System.out.println("Lista de ciudades disponibles:");

		        try {
		            // Crear una instancia de CiudadesProvider
		            CiudadesProvider ciudadesProvider = CiudadesProvider.instance();

		            // Mostrar la lista de ciudades disponibles
		            List<String> ciudades = ciudadesProvider.list();
		            for (int i = 0; i < ciudades.size(); i++) {
		                System.out.println((i + 1) + ". " + ciudades.get(i));
		            }

		            // Solicitar al usuario que elija un mapa
		            System.out.print("Seleccione un mapa ingresando su número: ");
		            int selectedMapIndex = scanner.nextInt();
		            if (selectedMapIndex < 1 || selectedMapIndex > ciudades.size()) {
		                System.out.println("Número de mapa no válido. Saliendo...");
		                return;
		            }

		            String selectedMap = ciudades.get(selectedMapIndex - 1);

		            // Realizar las operaciones necesarias con el mapa seleccionado
		            System.out.println("Mapa seleccionado: " + selectedMap);
		            Ciudad c = ciudadesProvider.ciudad(selectedMap);
		            
		            String archivoNodos = c.getXmlNodes();
		            String archivoEdges = c.getXmlEdges();
		            
		            System.out.println(c.getXmlEdges().length());
		            System.out.println(c.getXmlNodes().length());
		            
		            // Llamar al método cargarArchivosRemotos
		            ciudadesProvider.cargarArchivosRemotos(archivoNodos, archivoEdges);

		            // Actualizar la interfaz de usuario según sea necesario
		            // Asegúrate de que el statusLabel esté disponible en este contexto
		            // Si es parte de la clase Menu, puedes declararlo como un campo de clase.

		            System.out.println("Carga de archivos remotos completada");
		        } catch (IOException ex) {
		            ex.printStackTrace();
		            // Manejar la excepción según tus necesidades
		        } finally {
		            // Cerrar el scanner al finalizar
		            scanner.close();
		        }
		    }
		});
		cargarArchivosRemotos.setFont(new Font("Arial Black", Font.PLAIN, 14));
		cargarArchivosRemotos.setBounds(234, 200, 250, 30);
		panel2.add(cargarArchivosRemotos);
		// Agregar pestañas al JTabbedPane
		tabbedPane.addTab("Acciones Locales", null, panel1, "Realizar acciones locales");
		tabbedPane.addTab("Acciones Remotas", null, panel2, "Realizar acciones con archivos remotos");

		// Configurar el JFrame y agregar el JTabbedPane
		JFrame frame = new JFrame("Ejemplo de Pestañas con Botones");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(800, 600);

		frame.getContentPane().add(tabbedPane);

		// Hacer visible el JFrame
		frame.setVisible(true);
	}

	private static Map<String, Nodo> crearDiccionarioNodos(List<Nodo> nodos) {
		Map<String, Nodo> nodosMap = new HashMap<>();
		for (Nodo nodo : nodos) {
			nodosMap.put(nodo.getOsmid(), nodo);
		}
		return nodosMap;
	}
}
