package Pack;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.geom.AffineTransform;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

/**
 * La clase Ventana representa la ventana principal de la aplicación gráfica,
 * que muestra nodos y bordes, y permite la interacción del usuario.
 */
public final class Ventana extends JPanel {
  private List<Nodo> nodos;
  private List<Edge> bordes;
  private List<Nodo> nodosOriginales;
  private List<Edge> bordesOriginales;
  private double zoom = 1.0;
  private int prevMouseX;
  private int prevMouseY;
  private int panX;
  private int panY;
  private boolean panning = false;
  private double xv;
  private double yv;
  private double xv2;
  private double yv2;
  private List<Nodo> nodosSeleccionados = new ArrayList<>();


  /**
   * Constructor de la clase Ventana.
   *
   * @param nodos         La lista de nodos a mostrar en la ventana.
   * @param bordes        La lista de bordes que conectan los nodos.
   * @param xv            Coordenada X del vértice superior izquierdo de la ventana.
   * @param yv            Coordenada Y del vértice superior izquierdo de la ventana.
   * @param xv2           Coordenada X del vértice inferior derecho de la ventana.
   * @param yv2           Coordenada Y del vértice inferior derecho de la ventana.
   */
  public Ventana(List<Nodo> nodos, List<Edge> bordes, double xv, double yv, 
        double xv2, double yv2) {
    this.nodos = nodos;
    this.bordes = bordes;
    this.xv = xv;
    this.xv2 = xv2;
    this.yv = yv;
    this.yv2 = yv2;
    this.nodosOriginales = new ArrayList<>(nodos);
    this.bordesOriginales = new ArrayList<>(bordes);

    addMouseListener(new MouseAdapter() {
      @Override
    public void mousePressed(MouseEvent e) {

        if (SwingUtilities.isLeftMouseButton(e)) {
          prevMouseX = e.getX();
          prevMouseY = e.getY();
          panning = true;
          DecimalFormat f = new DecimalFormat("#.####");

          final double mouseX = (e.getX() - panX) / zoom; 
          final double mouseY = (e.getY() - panY) / zoom;

          // Buscar el nodo más cercano 
          Nodo nodoClic = encontrarNodoMasCercano(mouseX, mouseY);

          if (nodoClic != null) {

            // Si ya hay 2 nodos seleccionados, borrar la lista
            if (nodosSeleccionados.size() == 2) {
              for (Nodo n : nodosSeleccionados) {
                n.setDesmarcar();
              }
              nodosSeleccionados.clear();
              }
              nodosSeleccionados.add(nodoClic);
              if (!nodoClic.isMarcado()) {
                nodoClic.setMarcado(panning);
              }
              repaint();
              // Mostrar nodos
              if (nodosSeleccionados.size() == 2) {
                System.out.println("Nodos seleccionados:\n");
                  for (Nodo nodo : nodosSeleccionados) {
                    System.out.println(nodo.toString());
                  }

                  // Calcular y mostrar la distancia entre los nodos seleccionados
                  double distancia = calcularDistanciaEntreNodos(nodosSeleccionados.get(0),
                      nodosSeleccionados.get(1));
                  String dist = f.format(distancia);
                  System.out.println("Distancia entre los nodos seleccionados: " + distancia);
                  JOptionPane.showMessageDialog(null,
                		  "Distancia entre los nodos seleccionados: \n" + dist + " Km\nNodo 1: "
                          + nodosSeleccionados.get(0).getOsmid() + " \nX: "
                          + f.format(nodosSeleccionados.get(0).getX()) + "\nY: "
                          + f.format(nodosSeleccionados.get(0).getY()) + "\nNodo 2: "
                          + nodosSeleccionados.get(1).getOsmid() + " \nX: "
                          + f.format(nodosSeleccionados.get(1).getX()) + "\nY: "
                          + f.format(nodosSeleccionados.get(1).getY()));
            }

          }
        }
      }

      @Override
      public void mouseReleased(MouseEvent e) {
        if (SwingUtilities.isLeftMouseButton(e)) {
          panning = false;
        }
      }
    });

    final double[] xv1 = { this.xv };
    final double[] yv1 = { this.yv };
    final double[] xv3 = { this.xv2 };
    final double[] yv3 = { this.yv2 };
    
    addMouseMotionListener(new MouseAdapter() {
        @Override
        public void mouseDragged(MouseEvent e) {
            if (panning) {
                int deltaX = e.getX() - prevMouseX;
                int deltaY = e.getY() - prevMouseY;

                panX += deltaX;
                panY += deltaY;

                // Ajustar las coordenadas del área visible para reflejar el desplazamiento
                xv1[0] += deltaX / zoom;
                yv1[0] += deltaY / zoom;
                xv3[0] += deltaX / zoom;
                yv3[0] += deltaY / zoom;

                // Ralentizar el avance del clipping
                xv1[0] += 0.005 * deltaX / zoom;
                yv1[0] += 0.005 * deltaY / zoom;
                xv3[0] += 0.005 * deltaX / zoom;
                yv3[0] += 0.005 * deltaY / zoom;

                prevMouseX = e.getX();
                prevMouseY = e.getY();

                repaint();
            }
        }
    });


    // Agregar un MouseWheelListener para el zoom con la rueda del mouse
    addMouseWheelListener(new MouseAdapter() {
        @Override
        public void mouseWheelMoved(MouseWheelEvent e) {
            int notches = e.getWheelRotation();
            double zoomFactor = Math.pow(1.1, notches);

            // Obtener las coordenadas del punto en el que se encuentra 
            // el puntero del mouse antes del zoom
            Point mousePointBeforeZoom = e.getPoint();
            double preZoomX = (mousePointBeforeZoom.getX() - panX) / zoom;
            double preZoomY = (mousePointBeforeZoom.getY() - panY) / zoom;

            // Aplicar el zoom
            setZoom(getZoom() * zoomFactor);

            // Obtener las coordenadas del punto en el que se encuentra el 
            // puntero del mouse después del zoom
            Point mousePointAfterZoom = e.getPoint();
            double postZoomX = (mousePointAfterZoom.getX() - panX) / zoom;
            double postZoomY = (mousePointAfterZoom.getY() - panY) / zoom;

            // Ajustar el desplazamiento para mantener el punto bajo el puntero del mouse
            panX += (preZoomX - postZoomX) * zoom;
            panY += (preZoomY - postZoomY) * zoom;

            repaint();
        }
    });

    // Crear un botón para reiniciar el mapa

    JButton reiniciarBoton = new JButton("Reiniciar Mapa");
    reiniciarBoton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        reiniciarMapa();
      }
    });

    // Crear un JPanel para contener el botón de reinicio
    JPanel botonPanel = new JPanel();
    botonPanel.add(reiniciarBoton);

    setLayout(new BorderLayout());
    add(botonPanel, BorderLayout.NORTH);

    addComponentListener(new ComponentAdapter() {
      @Override
      public void componentResized(ComponentEvent e) {

      }
    });
  }

  private void reiniciarMapa() {
    // Restaura los nodos y bordes a su estado original
    nodos.clear();
    nodos.addAll(nodosOriginales);
    bordes.clear();
    bordes.addAll(bordesOriginales);

    // Restablece el zoom y el desplazamiento
    zoom = 1.0;
    panX = 0;
    panY = 0;
    for (Nodo n : nodos) {
      n.setDesmarcar();
      n.restablecerZoom();
    }

    // Repinta el mapa para reflejar los cambios
    repaint();
	}

  public void setZoom(double zoom) {
    this.zoom = zoom;
    repaint();
  }

  public double getZoom() {
    return zoom; 
  }

  private int escalarCoordenada(double valor, double rangoMinEntrada, 
            double rangoMaxEntrada, int rangoMinSalida,
            int rangoMaxSalida) {
    return (int) (((valor - rangoMinEntrada) * (rangoMaxSalida - rangoMinSalida))
      / (rangoMaxEntrada - rangoMinEntrada) + rangoMinSalida);
	}

  @Override
  protected void paintComponent(Graphics g) {
    super.paintComponent(g); 
    final Graphics2D g2d = (Graphics2D) g.create();

    g2d.translate(panX, panY);
    
    g2d.scale(zoom, zoom);
    
    for (Edge borde : bordes) {
      Nodo nodoFuente = borde.getNodoFuente();
      Nodo nodoDestino = borde.getNodoDestino();

      if (nodoFuente != null && nodoDestino != null) {
        // Verificar si tanto el nodo fuente como el destino son visibles
        if (nodoEsVisible(nodoFuente) && nodoEsVisible(nodoDestino)) {
          int x1 = escalarCoordenada(nodoFuente.getX(),
                  xv, xv2, 0, getWidth());
          int y1 = escalarCoordenada(nodoFuente.getY(), 
                  yv, yv2, 0, getHeight());
          int x2 = escalarCoordenada(nodoDestino.getX(), 
                  xv, xv2, 0, getWidth());
          int y2 = escalarCoordenada(nodoDestino.getY(), 
                  yv, yv2, 0, getHeight());

          // Aplicar el zoom a las coordenadas de los bordes
          x1 = (int) (x1 * zoom);
          y1 = (int) (y1 * zoom);
          x2 = (int) (x2 * zoom);
          y2 = (int) (y2 * zoom);

          // Dibujar el borde
          if (borde.getName().contains("Ruta")) {
            g2d.setColor(Color.red);
            g2d.drawLine(x1, y1, x2, y2);
            g2d.setColor(Color.red);
          } else if (borde.getName().contains("nan")) {
            g2d.setColor(Color.magenta);
            g2d.drawLine(x1, y1, x2, y2);
            g2d.setColor(Color.magenta);
          } else {
            g2d.setColor(Color.darkGray);
            g2d.drawLine(x1, y1, x2, y2);
            g2d.setColor(Color.darkGray);
          }
        }
      }
    }

    for (Nodo nodo : nodos) {
      int x = escalarCoordenada(nodo.getX(), xv, xv2, 0, getWidth());
      int y = escalarCoordenada(nodo.getY(), yv, yv2, 0, getHeight());

      // Aplicar el zoom a las coordenadas del nodo
      x = (int) (x * zoom);
      y = (int) (y * zoom);

      // Dibujar el nodo si es visible
      if (nodoEsVisible(nodo)) {
        // Asegurarse de que el método dibujar tenga en cuenta el zoom
        nodo.dibujar(g2d, getWidth(), getHeight(), zoom);
      }
    }

    g2d.dispose();
  }

  //Método para verificar si un nodo es visible en la ventana
  private boolean nodoEsVisible(Nodo nodo) {
    // Obtener las dimensiones actuales de la ventana
    int width = getWidth();
    int height = getHeight();

    // Obtener las coordenadas del nodo
    int x = escalarCoordenada(nodo.getX(), xv, xv2, 0, width);
    int y = escalarCoordenada(nodo.getY(), yv, yv2, 0, height);

    // Ajustar las coordenadas del nodo para reflejar el desplazamiento y el zoom
    int scaledX = (int) ((x - panX) * zoom);
    int scaledY = (int) ((y - panY) * zoom);

    // Ajustar el tamaño del nodo para reflejar el zoom
    int nodoWidth = (int) (nodo.NODO_ANCHO * zoom);
    int nodoHeight = (int) (nodo.NODO_ALTO * zoom);

    // Verificar si el nodo está dentro del área visible
    return (scaledX >= -nodoWidth && scaledX <= width && scaledY 
            >= -nodoHeight && scaledY <= height);
  }


  /**
   * Encuentra el nodo más cercano a las coordenadas especificadas,
   * teniendo en cuenta el zoom y la escala.
   *
   * @param mouseX La coordenada X del clic del ratón en el espacio original.
   * @param mouseY La coordenada Y del clic del ratón en el espacio original.
   * @return El nodo más cercano a las coordenadas especificadas
   * o null si no se encuentra ninguno.
   */
  public Nodo encontrarNodoMasCercano(double mouseX, double mouseY) {
    Nodo nodoMasCercano = null;
    double distanciaMinima = Double.MAX_VALUE; 

    for (Nodo nodo : nodos) {
      int x = escalarCoordenada(nodo.getX(), xv, xv2, 0, getWidth());
      int y = escalarCoordenada(nodo.getY(), yv, yv2, 0, getHeight());

      // Aplicar el zoom inverso a las coordenadas del nodo
      double nodoX = x / zoom;
      double nodoY = y / zoom;

      double distanciaX = nodoX - mouseX;
      double distanciaY = nodoY - mouseY;
      double distanciaCuadrado = distanciaX * distanciaX 
             + distanciaY * distanciaY;

      if (distanciaCuadrado < distanciaMinima) {
        distanciaMinima = distanciaCuadrado;
        nodoMasCercano = nodo;
      }
    }

    return nodoMasCercano;
  }

  private double calcularDistanciaEntreNodos(Nodo nodo1, Nodo nodo2) {
    final double lat1 = nodo1.getX();
    final double lon1 = nodo1.getY();
    final double lat2 = nodo2.getX();
    final double lon2 = nodo2.getY();
    final double distancia = calcularDistancia(lat1, lon1, lat2, lon2);
    return distancia;
  }

  private double calcularDistancia(double lat1, double lon1, 
      double lat2, double lon2) {
    double radioTierra = 6371.0;

    // Convertir las coordenadas de grados a radianes
    lat1 = Math.toRadians(lat1);
    lon1 = Math.toRadians(lon1);
    lat2 = Math.toRadians(lat2);
    lon2 = Math.toRadians(lon2);

    // Diferencias de latitud y longitud
    double dLat = lat2 - lat1;
    double dLon = lon2 - lon1;

    // Fórmula de Haversine
    double a = Math.pow(Math.sin(dLat / 2), 2) + Math.cos(lat1)
        * Math.cos(lat2) 
        * Math.pow(Math.sin(dLon / 2), 2);
    double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    // Calcular la distancia
    double distancia = radioTierra * c;

    return distancia;
  }
}