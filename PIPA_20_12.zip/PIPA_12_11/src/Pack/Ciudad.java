package Pack;

/**
 * La clase Ciudad representa una entidad que almacena 
 * las rutas de los archivos XML
 * de nodos y bordes asociados a una ciudad en el contexto 
 * de la aplicación de lectura de mapas.
 */
public class Ciudad {
  private final String xmlNodes; 
  private final String xmlEdges; 

  /**
   * Construye un objeto Ciudad a partir de la 
   * información proporcionada en archivos XML
   * que representan los nodos y bordes de la ciudad.
   *
   * @param xmlNodes Ruta al archivo XML que contiene 
   * la información de los nodos de la ciudad.
   * @param xmlEdges Ruta al archivo XML 
   * que contiene la información de los bordes (conexiones) entre nodos.
   */
  public Ciudad(final String xmlNodes, final String xmlEdges) {
    this.xmlNodes = xmlNodes;
    this.xmlEdges = xmlEdges;
  }

  /**
   * Obtiene la ruta al archivo XML que contiene 
   * la información de los nodos de la ciudad.
   *
   * @return La ruta al archivo XML de nodos.
   */
  public String getXmlNodes() {
    return xmlNodes;
  }

  /**
   * Obtiene la ruta al archivo XML que contiene la 
   * información de las aristas de la ciudad.
   *
   * @return La ruta al archivo XML de aristas.
   */
  public String getXmlEdges() {
    return xmlEdges;
  }
}
