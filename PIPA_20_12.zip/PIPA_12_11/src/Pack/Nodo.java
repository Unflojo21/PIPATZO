package Pack;

import java.awt.Color;
import java.awt.Graphics;

/**
 * La clase Nodo representa un nodo en un gráfico, con coordenadas (x, y) y otros atributos.
 */
public class Nodo {
  private double xValue;
  private double yValue;
  private double xAux;
  private double yAux;
  private String osmid;
  private Color color = Color.blue; // Color original
  private int originalTamanio = 2; 
  private int minimoTamanio = 2;
  private boolean marcado = false; // Indica si el nodo está marcado
  private double xv;
  private double xv2;
  private double yv;
  private double yv2;
  static final int NODO_ANCHO = 20; 
  static final int NODO_ALTO = 20; 

  /**
   * Constructor de la clase Nodo.
   *
   * @param xValue La coordenada X del nodo.
   * @param yValue La coordenada Y del nodo.
   * @param osmid  El identificador OSM del nodo.
   */
  public Nodo(double xValue, double yValue, String osmid) {
    this.xValue = xValue;
    this.yValue = yValue;
    this.xAux = xValue;
    this.yAux = yValue;
    this.osmid = osmid;
  }

  public void setXv(double xv) {
    this.xv = xv;
  }

  public void setXv2(double xv2) {
    this.xv2 = xv2;
  }

  public void setYv(double yv) {
    this.yv = yv;
  }

  public void setYv2(double yv2) {
    this.yv2 = yv2;
  }
  
  /**
   * Aplica un factor de zoom a las coordenadas X e Y del nodo.
   *
   * @param zoom El factor de zoom a aplicar.
   */
  public void zoom(double zoom) {
    this.xValue = this.xValue * zoom;
    this.yValue = this.yValue * zoom;
  }

  /**
   * Restablece las coordenadas X e Y del nodo a sus valores originales antes del zoom.
   */
  public void restablecerZoom() {
    this.xValue = this.xAux;
    this.yValue = this.yAux;
  }

  /**
   * Obtiene el color del nodo.
   *
   * @return El color del nodo.
   */
  public Color getColor() {
    return color;
  }

  /**
   * Establece el color del nodo.
   *
   * @param color El color a establecer.
   */
  public void setColor(Color color) {
    this.color = color;
  }

  /**
   * Obtiene el tamaño original del nodo.
   *
   * @return El tamaño original del nodo.
   */
  public int getOriginalTamanio() {
    return originalTamanio;
  }

  /**
   * Establece el tamaño original del nodo.
   *
   * @param originalTamanio El tamaño original a establecer.
   */
  public void setOriginalTamanio(int originalTamanio) {
    this.originalTamanio = originalTamanio;
  }

  /**
   * Obtiene la coordenada X del nodo.
   *
   * @return La coordenada X del nodo.
   */
  public double getX() {
    return xValue;
  }

  /**
   * Obtiene la coordenada Y del nodo.
   *
   * @return La coordenada Y del nodo.
   */
  public double getY() {
    return yValue;
  }

  /**
   * Obtiene el identificador OSM del nodo.
   *
   * @return El identificador OSM del nodo.
   */
  public String getOsmid() {
    return osmid;
  }

  /**
   * Verifica si el nodo está marcado.
   *
   * @return true si el nodo está marcado, false en caso contrario.
   */
  public boolean isMarcado() {
    return marcado;
  }

  /**
   * Establece el estado de marcado del nodo.
   *
   * @param marcado true si se debe marcar el nodo, false si se debe desmarcar.
   */
  public void setMarcado(boolean marcado) {
    this.marcado = marcado;

    // Cambiar el tamaño del nodo cuando se marca
    if (marcado) {
      originalTamanio += 20; // Aumentar el tamaño original (por ejemplo, x3)
    } else {
      originalTamanio = 3; // Restaurar el tamaño original
    }
  }

  /**
   * Desmarca el nodo, restaurando su estado original.
   * Si el nodo estaba marcado, este método lo desmarca y restablece su tamaño original.
   */
  public void setDesmarcar() {
    if (marcado) {
      marcado = false;
      originalTamanio = 2;
    }
  }

  /**
   * Dibuja el nodo en un contexto gráfico especificado, con ajuste de escala y zoom.
   *
   * @param g             El contexto gráfico en el que se dibuja el nodo.
   * @param panelWidth    Ancho del panel en el que se realiza el dibujo.
   * @param panelHeight   Altura del panel en el que se realiza el dibujo.
   * @param zoom          El nivel de zoom aplicado al dibujo.
   */
  public void dibujar(Graphics g, int panelWidth, int panelHeight, double zoom) {
    g.setColor(color);
    int scaledX = escalarCoordenada(xValue, xv, xv2, 0, panelWidth);
    int scaledY = escalarCoordenada(yValue, yv, yv2, 0, panelHeight);

    // Aplicar el zoom a las coordenadas escaladas
    scaledX = (int) (scaledX * zoom);
    scaledY = (int) (scaledY * zoom);

    // Calcular el tamaño escalado del nodo, asegurándose de que no sea menor que el tamaño mínimo
    int scaledSize = Math.max((int) (originalTamanio * zoom), minimoTamanio);

    g.fillOval(scaledX - 1, scaledY - 1, scaledSize, scaledSize);
    g.setColor(Color.black);
  }

  /**
   * Escala una coordenada de acuerdo a los rangos de entrada y salida especificados.
   *
   * @param valor            El valor a escalar.
   * @param rangoMinEntrada  El valor mínimo del rango de entrada.
   * @param rangoMaxEntrada  El valor máximo del rango de entrada.
   * @param rangoMinSalida   El valor mínimo del rango de salida.
   * @param rangoMaxSalida   El valor máximo del rango de salida.
   * @return La coordenada escalada.
   */
  private int escalarCoordenada(double valor, double rangoMinEntrada,
      double rangoMaxEntrada, int rangoMinSalida, int rangoMaxSalida) {
    return (int) (((valor - rangoMinEntrada) * (rangoMaxSalida - rangoMinSalida))
      / (rangoMaxEntrada - rangoMinEntrada) + rangoMinSalida);
  }
}
