package Pack;

import java.awt.Color;
import java.awt.Graphics;

/**
 * La clase Edge representa una conexión entre dos nodos en un grafo.
 * Contiene información sobre los nodos de origen y destino, así como
 * atributos asociados a la conexión.
 */
public class Edge {
  private String u;
  private String v;
  private int k;
  private String osmid;
  private String name;
  private Nodo nodoFuente;
  private Nodo nodoDestino;

  /**
   * Constructor de la clase Edge.
   *
   * @param u            Nodo de origen.
   * @param v            Nodo de destino.
   * @param k            Atributo k.
   * @param osmid        Identificador OSM.
   * @param name         Nombre asociado a la conexión.
   * @param nodoFuente2  Nodo de origen (objeto Nodo asociado).
   * @param nodoDestino2 Nodo de destino (objeto Nodo asociado).
   */
  public Edge(String u, String v, int k, String osmid, String name, 
         Nodo nodoFuente2, Nodo nodoDestino2) {
    this.u = u;
    this.v = v;
    this.k = k;
    this.osmid = osmid;
    this.name = name;
  }

  /**
   * Obtiene el nodo de origen.
   *
   * @return El nodo de origen.
   */
  public String getU() {
    return u;
  }

  /**
   * Establece el nodo de origen.
   *
   * @param u El nodo de origen a establecer.
   */
  public void setU(String u) {
    this.u = u;
  }

  /**
   * Obtiene el nodo de destino.
   *
   * @return El nodo de destino.
   */
  public String getV() {
    return v;
  }

  /**
   * Establece el nodo de destino.
   *
   * @param v El nodo de destino a establecer.
   */
  public void setV(String v) {
    this.v = v;
  }

  /**
   * Obtiene el atributo k.
   *
   * @return El atributo k.
   */
  public int getK() {
    return k;
  }

  /**
   * Establece el atributo k.
   *
   * @param k El atributo k a establecer.
   */
  public void setK(int k) {
    this.k = k;
  }

  /**
   * Obtiene el identificador OSM.
   *
   * @return El identificador OSM.
   */
  public String getOsmid() {
    return osmid;
  }

  /**
   * Establece el identificador OSM.
   *
   * @param osmid El identificador OSM a establecer.
   */
  public void setOsmid(String osmid) {
    this.osmid = osmid;
  }

  /**
   * Obtiene el nombre asociado a la conexión.
   *
   * @return El nombre asociado a la conexión.
   */
  public String getName() {
    return name;
  }

  /**
   * Establece el nombre asociado a la conexión.
   *
   * @param name El nombre asociado a la conexión a establecer.
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Obtiene el nodo de origen (objeto Nodo asociado).
   *
   * @return El nodo de origen (objeto Nodo asociado).
   */
  public Nodo getNodoFuente() {
    return nodoFuente;
  }

  /**
   * Establece el nodo de origen (objeto Nodo asociado).
   *
   * @param nodoFuente El nodo de origen (objeto Nodo asociado) a establecer.
   */
  public void setNodoFuente(Nodo nodoFuente) {
    this.nodoFuente = nodoFuente;
  }

  /**
   * Obtiene el nodo de destino (objeto Nodo asociado).
   *
   * @return El nodo de destino (objeto Nodo asociado).
   */
  public Nodo getNodoDestino() {
    return nodoDestino;
  }

  /**
   * Establece el nodo de destino (objeto Nodo asociado).
   *
   * @param nodoDestino El nodo de destino (objeto Nodo asociado) a establecer.
   */
  public void setNodoDestino(Nodo nodoDestino) {
    this.nodoDestino = nodoDestino;
  }
}
