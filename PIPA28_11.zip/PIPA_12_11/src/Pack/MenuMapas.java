package Pack;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 * Clase MenuMapas que representa un cuadro de diálogo para seleccionar un mapa.
 * Permite al usuario elegir entre varias ciudades y cargar el mapa correspondiente.
 */
public class MenuMapas extends JDialog {
  private JPanel panel;
  private static final String[] ciudades = { "Coquimbo", "La Serena", "Santiago", 
    "Antofagasta", "Punta Arenas" };

/**
* Constructor de la clase MenuMapas.
* Inicializa y configura un cuadro de diálogo para seleccionar un mapa.
* Agrega botones para cada ciudad disponible al cuadro de diálogo.
*/
  public MenuMapas() {
    setTitle("Seleccionar un mapa");
    setSize(300, 200);
    setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

    panel = new JPanel();
    panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

    for (String ciudad : ciudades) {
      addButton(ciudad);
    }

    add(panel);
  }

  private void addButton(final String ciudad) {
    JButton button = new JButton(ciudad);
    button.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        // Carga el mapa correspondiente cuando se hace clic en un botón
        cargarMapa(ciudad);
      }
    });
    panel.add(button);
  }

  private void cargarMapa(String cityName) {
    // Construir los nombres de los archivos de nodos y bordes
    String nodesFileName = cityName.toLowerCase() + "_nodes.xml";
    String edgesFileName = cityName.toLowerCase() + "_edges.xml";

    // Lógica para cargar el mapa desde los archivos nodes y edges

    JScrollPane scrollPane = new JScrollPane(panel);

    // Configurar las barras de desplazamiento
    scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

    // Crear el JFrame y configurarlo
    JFrame frame = new JFrame("Mapa de " + cityName);
    frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    frame.setSize(800, 600);
    frame.getContentPane().add(scrollPane);

    // Hacer visible el JFrame
    frame.setVisible(true);
  }

}
